<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mini-tiles" tilewidth="16" tileheight="16">
 <image source="mini-tiles.png" width="128" height="128"/>
 <tile id="0">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="2">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="3">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="8">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="9">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="10">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="11">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="16">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="17">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="18">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="19">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="24">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="25">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="32">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="33">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="40">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="41">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="48">
  <objectgroup draworder="index"/>
 </tile>
 <tile id="49">
  <objectgroup draworder="index"/>
 </tile>
</tileset>
